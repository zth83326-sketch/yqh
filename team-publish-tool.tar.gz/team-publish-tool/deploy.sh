#!/usr/bin/env bash
# yqh 团队版视频发布工具 —— 阿里云 ECS（Ubuntu 24.04）一键部署
# 用法（在服务器上以 root 身份执行）：
#   1. 把本目录所有文件传到服务器的 /opt/yqh-publish-tool/（或先传到 /tmp 再复制）
#   2. bash deploy.sh
# 脚本只装 Node 24、建专用用户、写 systemd 服务，不产生任何费用。
set -euo pipefail

APP_DIR=/opt/yqh-publish-tool
SERVICE=yqh-publish-tool

if [ "$(id -u)" -ne 0 ]; then echo "请用 root 身份执行：sudo bash deploy.sh"; exit 1; fi

echo "== 1/5 安装 Node.js 24 =="
if ! command -v node >/dev/null 2>&1 || ! node --version | grep -q '^v24'; then
  apt-get update -qq
  apt-get install -y -qq ca-certificates curl gnupg
  curl -fsSL https://deb.nodesource.com/setup_24.x | bash -
  apt-get install -y -qq nodejs
fi
node --version

echo "== 2/5 部署应用文件 =="
id -u yqh >/dev/null 2>&1 || useradd -r -m -s /usr/sbin/nologin yqh
mkdir -p "$APP_DIR"
# 如果脚本和应用文件在同一目录，就从当前目录复制；已在 $APP_DIR 里运行时跳过复制
if [ "$(pwd)" != "$APP_DIR" ] && [ -f ./server.js ]; then
  cp -r ./server.js ./package.json ./public ./yqh-publish-tool.service "$APP_DIR"/
fi
chown -R yqh:yqh "$APP_DIR"
chmod 700 "$APP_DIR"

echo "== 3/5 生成团队登录密码（只显示一次，请记下来分给团队成员） =="
if [ ! -f "$APP_DIR/.env" ]; then
  TEAM_PASS="$(head -c 18 /dev/urandom | base64 | tr -d '/+=' | head -c 20)"
  printf 'PORT=8080\nHOST=0.0.0.0\nTEAM_PASSWORD=%s\n' "$TEAM_PASS" > "$APP_DIR/.env"
  chmod 600 "$APP_DIR/.env"
  chown yqh:yqh "$APP_DIR/.env"
  echo "团队登录密码：$TEAM_PASS"
else
  echo ".env 已存在，沿用原密码（不显示）。"
fi

echo "== 4/5 安装 systemd 服务 =="
cp ./yqh-publish-tool.service /etc/systemd/system/ 2>/dev/null || cp "$APP_DIR/yqh-publish-tool.service" /etc/systemd/system/ 2>/dev/null || true
if [ ! -f /etc/systemd/system/$SERVICE.service ]; then
  echo "找不到 yqh-publish-tool.service，请确认它在当前目录或 $APP_DIR 下"; exit 1
fi
systemctl daemon-reload
systemctl enable --now $SERVICE

echo "== 5/5 检查 =="
sleep 2
systemctl status $SERVICE --no-pager | head -15
curl -s -o /dev/null -w "健康检查 HTTP %{http_code}\n" http://127.0.0.1:8080/api/health || true

IP="$(curl -s --max-time 10 ifconfig.me || hostname -I | awk '{print $1}')"
echo ""
echo "部署完成。团队访问地址：http://$IP:8080"
echo "注意：还需要在阿里云安全组放行 8080 端口（入方向 TCP 8080）。"

# TODO（登录方式待定）：当前为单密码门禁占位方案。团队定下“共用密码还是每人一个账号”
# 后，再启用对应方案（每人账号需在 server.js 里加 users 表和注册/管理页面）。
