// yqh 团队版视频发布工具 —— 独立部署版（零第三方依赖，Node 24+）
// 功能与 Muse 里的视频发布工具相同：上传/队列/定时/直接发布/发到草稿箱，
// 每条发布强制 is_aigc=true，通过 TikTok Content Posting API 官方接口发布。
// 数据存在本地 SQLite（data/app.db），视频文件存在 data/uploads/。
// 登录方式待定：当前为单密码门禁（TEAM_PASSWORD，见 README），团队定下
// “共用密码还是每人一个账号”后再换对应方案。

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = parseInt(process.env.PORT || '8080', 10);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const PUBLIC_DIR = path.join(__dirname, 'public');
const MAX_FILE_BYTES = 32 * 1024 * 1024; // 与 Muse 工具一致：上传上限 32MB
const TIKTOK_API = 'https://open.tiktokapis.com';

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ---------- 数据库 ----------
const db = new DatabaseSync(path.join(DATA_DIR, 'app.db'));
db.exec(`
CREATE TABLE IF NOT EXISTS connection (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  client_key TEXT NOT NULL DEFAULT '',
  client_secret TEXT NOT NULL DEFAULT '',
  access_token TEXT NOT NULL DEFAULT '',
  refresh_token TEXT NOT NULL DEFAULT '',
  expires_at INTEGER NOT NULL DEFAULT 0,
  creator_username TEXT DEFAULT '',
  creator_nickname TEXT DEFAULT '',
  creator_avatar_url TEXT DEFAULT '',
  privacy_level_options TEXT DEFAULT '[]',
  updated_at INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  source_type TEXT NOT NULL CHECK (source_type IN ('file','url')),
  source_url TEXT,
  blob_key TEXT,
  file_name TEXT,
  file_size INTEGER,
  privacy_level TEXT NOT NULL,
  publish_mode TEXT NOT NULL DEFAULT 'direct' CHECK (publish_mode IN ('direct','inbox')),
  disable_comment INTEGER NOT NULL DEFAULT 0,
  disable_duet INTEGER NOT NULL DEFAULT 0,
  disable_stitch INTEGER NOT NULL DEFAULT 0,
  scheduled_at INTEGER,
  status TEXT NOT NULL DEFAULT 'draft',
  publish_id TEXT,
  fail_reason TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`);

// ---------- 小工具 ----------
const now = () => Date.now();
function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(body);
}
function sendText(res, code, text, type = 'text/plain; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type });
  res.end(text);
}
function readBody(req, limit = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('请求体过大')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJson(req) {
  const buf = await readBody(req);
  if (!buf.length) return {};
  try { return JSON.parse(buf.toString('utf8')); } catch { throw new Error('JSON 解析失败'); }
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// ---------- 登录门禁（单密码，占位方案，等团队定下登录方式后再换） ----------
function authEnabled() {
  if (process.env.TEAM_PASSWORD) return true;
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('password_hash');
  return !!row;
}
function getPasswordHash() {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('password_hash');
  if (row) return row.value;
  if (process.env.TEAM_PASSWORD) {
    // 首次启动：把环境变量里的密码存成 scrypt 哈希，之后只认哈希
    const salt = crypto.randomBytes(16);
    const hash = crypto.scryptSync(process.env.TEAM_PASSWORD, salt, 64);
    const stored = `scrypt:${salt.toString('hex')}:${hash.toString('hex')}`;
    db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('password_hash', stored);
    return stored;
  }
  return null;
}
function checkPassword(pw) {
  const stored = getPasswordHash();
  if (!stored) return false;
  const [, saltHex, hashHex] = stored.split(':');
  const hash = crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), 64);
  return crypto.timingSafeEqual(hash, Buffer.from(hashHex, 'hex'));
}
function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k) out[k] = decodeURIComponent(v.join('='));
  }
  return out;
}
function authed(req) {
  if (!authEnabled()) return true; // 未设密码时为开放模式（仅用于本地测试，部署时必须设密码）
  const token = parseCookies(req).yqh_session;
  if (!token) return false;
  const row = db.prepare('SELECT * FROM sessions WHERE token = ? AND expires_at > ?').get(token, now());
  return !!row;
}
function setSession(res) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions (token, created_at, expires_at) VALUES (?, ?, ?)')
    .run(token, now(), now() + 7 * 24 * 3600 * 1000);
  res.setHeader('Set-Cookie', `yqh_session=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${7 * 24 * 3600}`);
}

// ---------- multipart 解析（只依赖内置模块） ----------
function parseMultipart(buf, boundary) {
  const fields = {};
  let file = null;
  const sep = Buffer.from(`--${boundary}`);
  let start = buf.indexOf(sep);
  if (start === -1) return { fields, file };
  start += sep.length;
  while (true) {
    if (buf[start] === 13 && buf[start + 1] === 10) start += 2; // \r\n
    else if (buf[start] === 45 && buf[start + 1] === 45) break; // -- 结束
    const headerEnd = buf.indexOf('\r\n\r\n', start);
    if (headerEnd === -1) break;
    const headers = buf.subarray(start, headerEnd).toString('utf8');
    const bodyStart = headerEnd + 4;
    let next = buf.indexOf(sep, bodyStart);
    if (next === -1) break;
    let bodyEnd = next - 2; // 去掉前面的 \r\n
    const nameMatch = headers.match(/name="([^"]+)"/);
    const fileMatch = headers.match(/filename="([^"]*)"/);
    if (nameMatch && fileMatch && fileMatch[1]) {
      file = { field: nameMatch[1], filename: fileMatch[1], data: buf.subarray(bodyStart, bodyEnd) };
    } else if (nameMatch) {
      fields[nameMatch[1]] = buf.subarray(bodyStart, bodyEnd).toString('utf8');
    }
    start = next + sep.length;
  }
  return { fields, file };
}
function safeBlobKey(name) {
  const base = path.basename(name).replace(/[^a-zA-Z0-9._-]/g, '_');
  return `${Date.now()}-${crypto.randomBytes(4).toString('hex')}-${base}`;
}

// ---------- TikTok API 客户端 ----------
// 逻辑与 Muse 里的视频发布工具一致（2026-11-19 沙盒实测通过）：
//  - Direct Post: POST /v2/post/publish/video/init/ (scope video.publish)
//  - 发到草稿箱: POST /v2/post/publish/inbox/video/init/ (scope video.upload)
//  - 每条发布强制 is_aigc=true；video_cover_timestamp_ms=1000
//  - 分片规则 planChunks：文件 <10MB 用单片（chunk_size = 文件大小）；
//    否则按 5MB 切分，总片数 = floor(大小/5MB)，保证每片 >=5MB
async function tiktokPost(path, token, body) {
  let res;
  try {
    res = await fetch(`${TIKTOK_API}${path}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body ?? {}),
      signal: AbortSignal.timeout(60000),
    });
  } catch (e) {
    throw new Error(e.name === 'TimeoutError' ? 'TikTok 请求超时（60 秒），请检查服务器网络后重试' : `TikTok 请求失败：${e.message}`);
  }
  const data = await res.json().catch(() => ({}));
  // TikTok 成功时也会返回 error 对象：{ code: 'ok', message: '' }，只有 code 不是 ok 才是真报错
  const apiErr = data?.error && data.error.code !== 'ok' ? data.error : null;
  if (!res.ok || apiErr) {
    const msg = apiErr?.message || apiErr?.code || `TikTok 请求失败（HTTP ${res.status}）`;
    const err = new Error(msg);
    err.code = apiErr?.code || `http_${res.status}`;
    throw err;
  }
  return data.data ?? data;
}
async function tiktokRefreshToken(conn) {
  const params = new URLSearchParams({
    client_key: conn.client_key,
    client_secret: conn.client_secret,
    grant_type: 'refresh_token',
    refresh_token: conn.refresh_token,
  });
  const res = await fetch(`${TIKTOK_API}/v2/oauth/token/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString(),
    signal: AbortSignal.timeout(30000),
  }).catch((e) => { throw new Error(e.name === 'TimeoutError' ? '刷新 Token 超时（30 秒），请重试' : `刷新 Token 失败：${e.message}`); });
  const data = await res.json().catch(() => ({}));
  const apiErr = data?.error && data.error.code !== 'ok' ? data.error : null;
  if (!res.ok || apiErr) {
    throw new Error(apiErr?.message || apiErr?.code || `刷新 Token 失败（HTTP ${res.status}）`);
  }
  const expiresAt = now() + (data.expires_in || 86400) * 1000;
  db.prepare(`UPDATE connection SET access_token = ?, refresh_token = ?, expires_at = ?, updated_at = ? WHERE id = 1`)
    .run(data.access_token, data.refresh_token || conn.refresh_token, expiresAt, now());
  return { ...conn, access_token: data.access_token, refresh_token: data.refresh_token || conn.refresh_token, expires_at: expiresAt };
}
function getConnection() {
  return db.prepare('SELECT * FROM connection WHERE id = 1').get() || null;
}
async function ensureToken() {
  const conn = getConnection();
  if (!conn || !conn.access_token) throw new Error('未连接 TikTok 账号，请先在连接区填写凭证并连接');
  if (conn.refresh_token && conn.expires_at && conn.expires_at - now() < 10 * 60 * 1000) {
    return tiktokRefreshToken(conn); // 10 分钟内过期就先刷新
  }
  return conn;
}
async function fetchCreatorInfo(conn) {
  return tiktokPost('/v2/post/publish/creator_info/query/', conn.access_token, {});
}
function planChunks(videoSize) {
  // 与 Muse 工具一致的 planChunks：<10MB 单片；否则按 5MB 切，每片 >=5MB
  const MIN_CHUNK = 5 * 1024 * 1024;
  if (videoSize < 2 * MIN_CHUNK) return { chunkSize: videoSize, totalChunks: 1 };
  const totalChunks = Math.floor(videoSize / MIN_CHUNK);
  const chunkSize = Math.ceil(videoSize / totalChunks);
  return { chunkSize, totalChunks };
}
async function uploadChunks(uploadUrl, filePath, videoSize) {
  const { chunkSize, totalChunks } = planChunks(videoSize);
  const fd = await fs.promises.open(filePath, 'r');
  try {
    for (let i = 0; i < totalChunks; i++) {
      const start = i * chunkSize;
      const end = Math.min(start + chunkSize, videoSize) - 1;
      const len = end - start + 1;
      const buf = Buffer.alloc(len);
      await fd.read(buf, 0, len, start);
      const res = await fetch(uploadUrl, {
        method: 'PUT',
        headers: { 'Content-Type': 'video/mp4', 'Content-Range': `bytes ${start}-${end}/${videoSize}` },
        body: buf,
        signal: AbortSignal.timeout(300000),
      });
      if (![200, 201, 204].includes(res.status)) {
        throw new Error(`上传分片 ${i + 1}/${totalChunks} 失败（HTTP ${res.status}）`);
      }
    }
  } finally { await fd.close(); }
}

// ---------- 发布流水线 ----------
function postRow(id) { return db.prepare('SELECT * FROM posts WHERE id = ?').get(id); }
function setPost(id, patch) {
  const keys = Object.keys(patch);
  const vals = keys.map((k) => patch[k]);
  db.prepare(`UPDATE posts SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ? WHERE id = ?`)
    .run(...vals, now(), id);
}
async function publishPost(post) {
  const conn = await ensureToken();
  const initPath = post.publish_mode === 'inbox'
    ? '/v2/post/publish/inbox/video/init/'
    : '/v2/post/publish/video/init/';
  let sourceInfo;
  let filePath = null;
  if (post.source_type === 'url') {
    sourceInfo = { source: 'PULL_FROM_URL', video_url: post.source_url };
  } else {
    filePath = path.join(UPLOAD_DIR, post.blob_key);
    if (!fs.existsSync(filePath)) throw new Error('找不到这条的视频文件，或文件为空');
    const size = fs.statSync(filePath).size;
    if (!size) throw new Error('找不到这条的视频文件，或文件为空');
    const { chunkSize, totalChunks } = planChunks(size);
    sourceInfo = { source: 'FILE_UPLOAD', video_size: size, chunk_size: chunkSize, total_chunk_count: totalChunks };
  }
  const init = await tiktokPost(initPath, conn.access_token, {
    post_info: {
      title: post.title,
      privacy_level: post.privacy_level,
      disable_duet: !!post.disable_duet,
      disable_comment: !!post.disable_comment,
      disable_stitch: !!post.disable_stitch,
      video_cover_timestamp_ms: 1000,
      is_aigc: true, // 强制 AI 生成标注
    },
    source_info: sourceInfo,
  });
  if (!init.publish_id) throw new Error('TikTok 未返回 publish_id');
  if (filePath && init.upload_url) {
    await uploadChunks(init.upload_url, filePath, fs.statSync(filePath).size);
  }
  return init.publish_id;
}
async function syncOnePost(post) {
  if (!post.publish_id) return post;
  const conn = await ensureToken();
  const data = await tiktokPost('/v2/post/publish/status/fetch/', conn.access_token, { publish_id: post.publish_id });
  const status = data.status;
  if (status === 'PUBLISH_COMPLETE') {
    setPost(post.id, { status: post.publish_mode === 'inbox' ? 'inboxed' : 'published', fail_reason: null });
  } else if (status === 'PUBLISH_FAILED') {
    setPost(post.id, { status: 'failed', fail_reason: data.fail_reason || '发布失败' });
  }
  return postRow(post.id);
}
async function syncPublishing() {
  const rows = db.prepare(`SELECT * FROM posts WHERE status = 'publishing'`).all();
  const out = [];
  for (const row of rows) {
    try { out.push(await syncOnePost(row)); }
    catch (e) { out.push({ ...row, error: e.message }); }
  }
  return out;
}
async function runQueue() {
  const synced = await syncPublishing();
  const due = db.prepare(`SELECT * FROM posts WHERE status = 'scheduled' AND scheduled_at IS NOT NULL AND scheduled_at <= ? ORDER BY scheduled_at ASC LIMIT 5`).all(now());
  const results = [];
  for (const post of due) {
    try {
      setPost(post.id, { status: 'publishing', fail_reason: null });
      const publishId = await publishPost(postRow(post.id));
      setPost(post.id, { publish_id: publishId });
      results.push({ id: post.id, ok: true, publish_id: publishId });
    } catch (e) {
      setPost(post.id, { status: 'failed', fail_reason: e.message });
      results.push({ id: post.id, ok: false, error: e.message });
    }
  }
  return { synced: synced.length, published: results };
}
setInterval(() => { runQueue().catch((e) => console.error('[queue]', e.message)); }, 15 * 60 * 1000);

// ---------- HTTP 路由 ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.txt': 'text/plain; charset=utf-8', '.mp4': 'video/mp4' };
function serveStatic(req, res, urlPath) {
  let p = urlPath === '/' ? '/index.html' : urlPath;
  const file = path.join(PUBLIC_DIR, decodeURIComponent(p));
  if (!file.startsWith(PUBLIC_DIR) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    return sendText(res, 404, 'Not found');
  }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}
function publicPost(p) {
  const r = postRow(p.id);
  if (!r) return null;
  const { blob_key, ...rest } = r;
  return { ...rest, previewUrl: r.source_type === 'file' ? `/api/media/${encodeURIComponent(blob_key)}` : null };
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const p = url.pathname;
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');

    // 登录 / 健康检查（不需要会话）
    if (p === '/api/health') return json(res, 200, { ok: true, authEnabled: authEnabled(), time: new Date().toISOString() });
    if (p === '/api/login' && req.method === 'POST') {
      const body = await readJson(req);
      if (!authEnabled()) return json(res, 200, { ok: true, open: true });
      if (typeof body.password === 'string' && checkPassword(body.password)) {
        setSession(res);
        return json(res, 200, { ok: true });
      }
      return json(res, 401, { error: '密码不正确' });
    }
    if (p === '/api/logout' && req.method === 'POST') {
      const token = parseCookies(req).yqh_session;
      if (token) db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
      res.setHeader('Set-Cookie', 'yqh_session=; HttpOnly; Path=/; Max-Age=0');
      return json(res, 200, { ok: true });
    }
    if (p === '/api/me') return json(res, 200, { authed: authed(req), authEnabled: authEnabled() });

    // 其余接口与页面都需要登录（未设密码时为开放模式）
    if (!authed(req)) {
      if (p.startsWith('/api/')) return json(res, 401, { error: '请先登录' });
      return serveStatic(req, res, '/login.html');
    }

    // ---- 连接 ----
    if (p === '/api/connection' && req.method === 'GET') {
      const c = getConnection();
      if (!c || !c.access_token) return json(res, 200, { connected: false });
      let options = [];
      try { options = JSON.parse(c.privacy_level_options || '[]'); } catch {}
      return json(res, 200, {
        connected: true,
        creator: { username: c.creator_username, nickname: c.creator_nickname, avatarUrl: c.creator_avatar_url },
        privacyLevelOptions: options,
        expiresAt: c.expires_at || null,
      });
    }
    if (p === '/api/connect' && req.method === 'POST') {
      const b = await readJson(req);
      const clientKey = String(b.clientKey || '').trim();
      const clientSecret = String(b.clientSecret || '').trim();
      const accessToken = String(b.accessToken || '').trim();
      const refreshToken = String(b.refreshToken || '').trim();
      if (!clientKey || !clientSecret || !accessToken) return json(res, 400, { error: '请填写 Client Key、Client Secret 和 Access Token' });
      const info = await tiktokPost('/v2/post/publish/creator_info/query/', accessToken, {});
      db.prepare(`INSERT INTO connection (id, client_key, client_secret, access_token, refresh_token, expires_at, creator_username, creator_nickname, creator_avatar_url, privacy_level_options, updated_at)
        VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET client_key=excluded.client_key, client_secret=excluded.client_secret, access_token=excluded.access_token, refresh_token=excluded.refresh_token, expires_at=excluded.expires_at, creator_username=excluded.creator_username, creator_nickname=excluded.creator_nickname, creator_avatar_url=excluded.creator_avatar_url, privacy_level_options=excluded.privacy_level_options, updated_at=excluded.updated_at`)
        .run(clientKey, clientSecret, accessToken, refreshToken, now() + 24 * 3600 * 1000,
          info.creator_username || '', info.creator_nickname || '', info.creator_avatar_url || '',
          JSON.stringify(info.privacy_level_options || []), now());
      return json(res, 200, { ok: true, creator: { username: info.creator_username, nickname: info.creator_nickname } });
    }
    if (p === '/api/disconnect' && req.method === 'POST') {
      db.prepare(`UPDATE connection SET access_token='', refresh_token='', expires_at=0, creator_username='', creator_nickname='', creator_avatar_url='', privacy_level_options='[]', updated_at=? WHERE id=1`).run(now());
      return json(res, 200, { ok: true });
    }
    if (p === '/api/refresh' && req.method === 'POST') {
      const conn = await ensureToken();
      const info = await fetchCreatorInfo(conn);
      db.prepare(`UPDATE connection SET creator_username=?, creator_nickname=?, creator_avatar_url=?, privacy_level_options=?, updated_at=? WHERE id=1`)
        .run(info.creator_username || '', info.creator_nickname || '', info.creator_avatar_url || '', JSON.stringify(info.privacy_level_options || []), now());
      return json(res, 200, { ok: true });
    }

    // ---- 视频文件 ----
    if (p === '/api/upload' && req.method === 'POST') {
      const ct = req.headers['content-type'] || '';
      const m = ct.match(/boundary=(?:"([^"]+)"|([^;]+))/);
      if (!m) return json(res, 400, { error: '请用 multipart 表单上传视频' });
      const buf = await readBody(req, MAX_FILE_BYTES + 1024 * 1024);
      if (buf.length > MAX_FILE_BYTES) return json(res, 400, { error: '视频超过 32MB 上限' });
      const { file } = parseMultipart(buf, (m[1] || m[2]).trim());
      if (!file || !file.data.length) return json(res, 400, { error: '没有收到视频文件' });
      if (file.data.length > MAX_FILE_BYTES) return json(res, 400, { error: '视频超过 32MB 上限' });
      const key = safeBlobKey(file.filename || 'video.mp4');
      await fs.promises.writeFile(path.join(UPLOAD_DIR, key), file.data);
      return json(res, 200, { ok: true, blobKey: key, fileName: file.filename, fileSize: file.data.length });
    }
    if (p.startsWith('/api/media/') && req.method === 'GET') {
      const key = decodeURIComponent(p.slice('/api/media/'.length));
      if (!key || key.includes('/') || key.includes('..')) return sendText(res, 400, 'Bad key');
      const file = path.join(UPLOAD_DIR, key);
      if (!fs.existsSync(file)) return sendText(res, 404, 'Not found');
      res.writeHead(200, { 'Content-Type': 'video/mp4', 'Accept-Ranges': 'bytes' });
      fs.createReadStream(file).pipe(res);
      return;
    }

    // ---- 队列 ----
    if (p === '/api/posts' && req.method === 'GET') {
      const rows = db.prepare('SELECT * FROM posts ORDER BY id DESC').all();
      return json(res, 200, { posts: rows.map((r) => { const { blob_key, ...rest } = r; return { ...rest, previewUrl: r.source_type === 'file' ? `/api/media/${encodeURIComponent(blob_key)}` : null }; }) });
    }
    if (p === '/api/posts' && req.method === 'POST') {
      const b = await readJson(req);
      const title = String(b.title || '').trim();
      if (!title || title.length > 2200) return json(res, 400, { error: '请填写文案（最多 2200 字）' });
      if (!['file', 'url'].includes(b.sourceType)) return json(res, 400, { error: '请选择视频来源' });
      if (b.sourceType === 'file' && !b.blobKey) return json(res, 400, { error: '请先上传视频' });
      if (b.sourceType === 'file' && (String(b.blobKey).includes('/') || String(b.blobKey).includes('..') || !fs.existsSync(path.join(UPLOAD_DIR, b.blobKey)))) {
        return json(res, 400, { error: '找不到上传的视频文件，请重新上传' });
      }
      if (b.sourceType === 'url' && !b.sourceUrl) return json(res, 400, { error: '请填写视频链接' });
      const privacy = String(b.privacyLevel || 'SELF_ONLY');
      const mode = b.publishMode === 'inbox' ? 'inbox' : 'direct';
      const scheduledAt = b.scheduledAt ? Date.parse(b.scheduledAt) : null;
      const info = db.prepare(`INSERT INTO posts (title, source_type, source_url, blob_key, file_name, file_size, privacy_level, publish_mode, disable_comment, disable_duet, disable_stitch, scheduled_at, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(title, b.sourceType, b.sourceUrl || null, b.blobKey || null, b.fileName || null, b.fileSize || null,
          privacy, mode, b.disableComment ? 1 : 0, b.disableDuet ? 1 : 0, b.disableStitch ? 1 : 0,
          scheduledAt && !Number.isNaN(scheduledAt) ? scheduledAt : null,
          scheduledAt ? 'scheduled' : 'draft', now(), now());
      return json(res, 200, { ok: true, post: publicPost({ id: Number(info.lastInsertRowid) }) });
    }
    const postIdMatch = p.match(/^\/api\/posts\/(\d+)(\/(publish))?$/);
    if (postIdMatch) {
      const id = Number(postIdMatch[1]);
      const post = postRow(id);
      if (!post) return json(res, 404, { error: '找不到这条' });
      if (req.method === 'DELETE') {
        if (post.source_type === 'file' && post.blob_key) {
          await fs.promises.unlink(path.join(UPLOAD_DIR, post.blob_key)).catch(() => {});
        }
        db.prepare('DELETE FROM posts WHERE id = ?').run(id);
        return json(res, 200, { ok: true });
      }
      if (postIdMatch[3] === 'publish' && req.method === 'POST') {
        if (!['draft', 'scheduled', 'failed'].includes(post.status)) return json(res, 400, { error: '这条当前不能发布' });
        try {
          setPost(id, { status: 'publishing', fail_reason: null });
          const publishId = await publishPost(postRow(id));
          setPost(id, { publish_id: publishId });
          const mode = post.publish_mode === 'inbox' ? 'inbox' : 'direct';
          return json(res, 200, { ok: true, publishMode: mode, publishId, message: mode === 'inbox' ? '已发到草稿箱，请打开 TikTok 草稿箱手动发布（可挂商品链接）' : '已发布到主页' });
        } catch (e) {
          setPost(id, { status: 'failed', fail_reason: e.message });
          return json(res, 400, { error: e.message });
        }
      }
      if (req.method === 'PATCH') {
        if (!['draft', 'scheduled', 'failed'].includes(post.status)) return json(res, 400, { error: '已发布或发布中的内容不能编辑' });
        const b = await readJson(req);
        const title = String(b.title || '').trim();
        if (!title || title.length > 2200) return json(res, 400, { error: '请填写文案（最多 2200 字）' });
        const scheduledAt = b.scheduledAt ? Date.parse(b.scheduledAt) : null;
        setPost(id, {
          title,
          privacy_level: String(b.privacyLevel || post.privacy_level),
          publish_mode: b.publishMode === 'inbox' ? 'inbox' : 'direct',
          disable_comment: b.disableComment ? 1 : 0,
          disable_duet: b.disableDuet ? 1 : 0,
          disable_stitch: b.disableStitch ? 1 : 0,
          scheduled_at: scheduledAt && !Number.isNaN(scheduledAt) ? scheduledAt : null,
          status: scheduledAt ? 'scheduled' : 'draft',
        });
        return json(res, 200, { ok: true, post: publicPost({ id }) });
      }
      return json(res, 405, { error: '不支持的方法' });
    }
    if (p === '/api/sync' && req.method === 'POST') {
      const out = await syncPublishing();
      return json(res, 200, { ok: true, synced: out.length });
    }
    if (p === '/api/run-queue' && req.method === 'POST') {
      const out = await runQueue();
      return json(res, 200, { ok: true, ...out });
    }

    // 静态页面
    if (req.method === 'GET') return serveStatic(req, res, p);
    return json(res, 404, { error: 'Not found' });
  } catch (e) {
    console.error('[error]', e);
    if (!res.headersSent) json(res, 500, { error: e.message || '服务器错误' });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`yqh 团队版视频发布工具已启动：http://${HOST === '0.0.0.0' ? '服务器IP' : HOST}:${PORT}`);
  console.log(`数据目录：${DATA_DIR}；登录门禁：${authEnabled() ? '已启用（单密码，占位方案）' : '未启用（未设置 TEAM_PASSWORD，仅用于本地测试）'}`);
  console.log('队列每 15 分钟自动运行一次。');
});

export { planChunks };
