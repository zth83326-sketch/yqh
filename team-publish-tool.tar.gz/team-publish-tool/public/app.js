const $ = (s) => document.querySelector(s);
const STATUS_TEXT = { draft: '草稿', scheduled: '已定时', publishing: '发布中', published: '已发布', inboxed: '已发到草稿箱', failed: '失败' };
const PRIVACY_TEXT = { SELF_ONLY: '仅自己可见', PUBLIC_TO_EVERYONE: '公开', MUTUAL_FOLLOW_FRIENDS: '互关好友可见' };
let uploaded = null; // {blobKey, fileName, fileSize}
let sourceType = 'file';
let editingId = null;

async function api(path, opts = {}) {
  const res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `请求失败（${res.status}）`);
  return data;
}

async function loadConnection() {
  const c = await api('/api/connection');
  const badge = $('#connBadge');
  const view = $('#connView');
  if (!c.connected) {
    badge.textContent = '未连接';
    badge.className = 'badge warn';
    view.innerHTML = '<p class="hint">还没有连接 TikTok 账号。请在下面填写凭证并连接。</p>';
    return;
  }
  badge.textContent = `已连接 @${c.creator.username || ''}`;
  badge.className = 'badge ok';
  const exp = c.expiresAt ? new Date(c.expiresAt).toLocaleString('zh-CN') : '未知';
  view.innerHTML = `<div class="creator">
    ${c.creator.avatarUrl ? `<img src="${c.creator.avatarUrl}" class="avatar" alt="">` : ''}
    <div><b>${esc(c.creator.nickname || '')}</b> <span class="muted">@${esc(c.creator.username || '')}</span><br>
    <span class="muted">Token 有效期到：${exp}；可选隐私：${(c.privacyLevelOptions || []).join(' / ') || '—'}</span></div>
  </div>`;
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

async function loadPosts() {
  const { posts } = await api('/api/posts');
  const list = $('#postList');
  if (!posts.length) { list.innerHTML = '<p class="hint">队列是空的。</p>'; return; }
  list.innerHTML = posts.map((p) => {
    const when = p.scheduled_at ? new Date(p.scheduled_at).toLocaleString('zh-CN') : '—';
    const media = p.previewUrl
      ? `<video src="${p.previewUrl}" controls preload="metadata" class="thumb"></video>`
      : `<a href="${esc(p.source_url || '')}" target="_blank" rel="noopener">视频链接</a>`;
    const canPublish = ['draft', 'scheduled', 'failed'].includes(p.status);
    const canEdit = ['draft', 'scheduled', 'failed'].includes(p.status);
    return `<div class="item">
      <div class="item-media">${media}</div>
      <div class="item-body">
        <div class="item-title">${esc(p.title)}</div>
        <div class="muted">${p.publish_mode === 'inbox' ? '发到草稿箱' : '直接发布到主页'} · ${PRIVACY_TEXT[p.privacy_level] || p.privacy_level} · 定时：${when}</div>
        <div class="muted">${p.publish_id ? 'publish_id：' + esc(p.publish_id) : ''} ${p.fail_reason ? '失败原因：' + esc(p.fail_reason) : ''}</div>
        <div class="row">
          <span class="badge ${p.status === 'published' || p.status === 'inboxed' ? 'ok' : p.status === 'failed' ? 'bad' : p.status === 'publishing' ? 'warn' : ''}">${STATUS_TEXT[p.status] || p.status}</span>
          ${canPublish ? `<button class="btn small primary" data-act="publish" data-id="${p.id}">立即发布</button>` : ''}
          ${canEdit ? `<button class="btn small" data-act="edit" data-id="${p.id}">编辑</button>` : ''}
          <button class="btn small danger" data-act="delete" data-id="${p.id}">删除</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

async function refreshAll() { await loadConnection(); await loadPosts(); }

// 连接表单
$('#connForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const msg = $('#connMsg');
  msg.textContent = '正在验证…';
  try {
    const r = await api('/api/connect', { method: 'POST', body: JSON.stringify(Object.fromEntries(fd)) });
    msg.textContent = `已连接 @${r.creator.username || ''}`;
    e.target.reset();
    await refreshAll();
  } catch (err) { msg.textContent = '连接失败：' + err.message; }
});
$('#refreshConnBtn').addEventListener('click', async () => {
  const msg = $('#connMsg');
  try { await api('/api/refresh', { method: 'POST' }); msg.textContent = '已刷新'; await refreshAll(); }
  catch (err) { msg.textContent = '刷新失败：' + err.message; }
});
$('#disconnectBtn').addEventListener('click', async () => {
  if (!confirm('确定断开 TikTok 连接吗？（应用凭证会保留，重连只需新的 Token）')) return;
  await api('/api/disconnect', { method: 'POST' });
  await refreshAll();
});

// 新建发布：来源切换
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');
    sourceType = tab.dataset.source;
    $('#filePane').style.display = sourceType === 'file' ? '' : 'none';
    $('#urlPane').style.display = sourceType === 'url' ? '' : 'none';
  });
});
$('#videoFile').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  const info = $('#fileInfo');
  const prev = $('#preview');
  uploaded = null;
  if (!f) { info.textContent = ''; prev.style.display = 'none'; return; }
  if (f.size > 32 * 1024 * 1024) { info.textContent = '视频超过 32MB 上限'; return; }
  info.textContent = `正在上传 ${f.name}（${(f.size / 1024 / 1024).toFixed(2)}MB）…`;
  const fd = new FormData();
  fd.append('video', f);
  try {
    const res = await fetch('/api/upload', { method: 'POST', body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '上传失败');
    uploaded = data;
    info.textContent = `已上传：${f.name}（${(f.size / 1024 / 1024).toFixed(2)}MB）`;
    prev.src = URL.createObjectURL(f);
    prev.style.display = '';
  } catch (err) { info.textContent = '上传失败：' + err.message; }
});
$('#postForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = $('#postMsg');
  const scheduledAt = $('#scheduledAt').value ? new Date($('#scheduledAt').value).toISOString() : null;
  const body = {
    title: $('#title').value.trim(),
    sourceType,
    blobKey: sourceType === 'file' ? uploaded?.blobKey : null,
    fileName: sourceType === 'file' ? uploaded?.fileName : null,
    fileSize: sourceType === 'file' ? uploaded?.fileSize : null,
    sourceUrl: sourceType === 'url' ? $('#sourceUrl').value.trim() : null,
    privacyLevel: $('#privacyLevel').value,
    publishMode: $('#publishMode').value,
    scheduledAt,
    disableComment: $('#disableComment').checked,
    disableDuet: $('#disableDuet').checked,
    disableStitch: $('#disableStitch').checked,
  };
  msg.textContent = '正在加入队列…';
  try {
    await api('/api/posts', { method: 'POST', body: JSON.stringify(body) });
    msg.textContent = scheduledAt ? '已加入队列，将按定时发布。' : '已加入队列（草稿）。';
    e.target.reset();
    uploaded = null;
    $('#preview').style.display = 'none';
    $('#fileInfo').textContent = '';
    await loadPosts();
  } catch (err) { msg.textContent = '失败：' + err.message; }
});

// 队列操作
$('#postList').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const id = btn.dataset.id;
  const act = btn.dataset.act;
  if (act === 'delete') {
    if (!confirm('确定删除这条吗？上传的视频文件也会一起删掉。')) return;
    await api(`/api/posts/${id}`, { method: 'DELETE' });
  } else if (act === 'publish') {
    btn.disabled = true;
    btn.textContent = '发布中…';
    try {
      const r = await api(`/api/posts/${id}/publish`, { method: 'POST' });
      alert(r.message || '已提交');
    } catch (err) { alert('发布失败：' + err.message); }
  } else if (act === 'edit') {
    const { posts } = await api('/api/posts');
    const p = posts.find((x) => String(x.id) === String(id));
    if (!p) return;
    editingId = id;
    $('#editTitle').value = p.title;
    $('#editPrivacy').value = p.privacy_level;
    $('#editMode').value = p.publish_mode;
    $('#editScheduledAt').value = p.scheduled_at ? new Date(p.scheduled_at - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '';
    $('#editDisableComment').checked = !!p.disable_comment;
    $('#editDisableDuet').checked = !!p.disable_duet;
    $('#editDisableStitch').checked = !!p.disable_stitch;
    document.getElementById('editDlg').showModal();
  }
  await loadPosts();
});
$('#editForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const scheduledAt = $('#editScheduledAt').value ? new Date($('#editScheduledAt').value).toISOString() : null;
  await api(`/api/posts/${editingId}`, {
    method: 'PATCH',
    body: JSON.stringify({
      title: $('#editTitle').value.trim(),
      privacyLevel: $('#editPrivacy').value,
      publishMode: $('#editMode').value,
      scheduledAt,
      disableComment: $('#editDisableComment').checked,
      disableDuet: $('#editDisableDuet').checked,
      disableStitch: $('#editDisableStitch').checked,
    }),
  });
  document.getElementById('editDlg').close();
  await loadPosts();
});
$('#syncBtn').addEventListener('click', async () => { await api('/api/sync', { method: 'POST' }); await loadPosts(); });
$('#runQueueBtn').addEventListener('click', async () => { await api('/api/run-queue', { method: 'POST' }); await loadPosts(); });
$('#logoutBtn').addEventListener('click', async () => {
  await api('/api/logout', { method: 'POST' });
  location.href = '/login.html';
});

refreshAll().catch((err) => {
  if (err.message.includes('401')) location.href = '/login.html';
});
