# yqh 团队版视频发布工具（独立部署版）

功能与 Muse 里的视频发布工具相同：上传视频 / 发布队列 / 定时发布 / 直接发布到主页 / 发到草稿箱，每条发布强制 AI 生成标注（is_aigc=true），通过 TikTok Content Posting API 官方接口发布。

## 技术要点

- 零第三方依赖，只需 Node.js 24+（用到内置 `node:sqlite`），不用 npm install。
- 数据存在服务器本地 SQLite（`data/app.db`），视频文件存在 `data/uploads/`。
- 队列每 15 分钟自动运行：先同步发布中的状态，再把到时间的定时发布发出去（每次最多 5 条）。
- 分片上传规则（与 Muse 工具一致，2026-11-19 沙盒实测通过）：文件 <10MB 用单片（chunk_size = 文件大小）；否则按 5MB 切分，保证每片 ≥5MB。
- Token 自动续期：Access Token 快过期（10 分钟内）且有 Refresh Token 时自动刷新。

## 部署（阿里云 ECS，Ubuntu 24.04）

1. 阿里云安全组放行入方向 TCP 8080（团队内部用 `http://公网IP:8080` 访问，不需要域名和 ICP 备案）。
2. 把本目录所有文件传到服务器的 `/opt/yqh-publish-tool/`。
3. 以 root 身份执行：`bash /opt/yqh-publish-tool/deploy.sh`
4. 脚本会装 Node 24、生成团队登录密码（只显示一次，请记下来分给团队成员）、启动 systemd 服务 `yqh-publish-tool`。
5. 打开 `http://公网IP:8080`，用团队登录密码登录。

常用命令：`systemctl status yqh-publish-tool` / `systemctl restart yqh-publish-tool` / `journalctl -u yqh-publish-tool -f`。

## 接入 TikTok（先沙盒测试，审核通过后再接店号）

1. 打开团队站点的「TikTok 连接」区，填写：
   - Client Key（沙盒应用的 Key）
   - Client Secret（沙盒应用的 Secret，粘贴一次，只存在服务器上）
   - Access Token、Refresh Token（可选，有就填上）
2. 点「连接并验证」——工具会调 `creator_info/query` 验证 Token，成功后显示创作者账号。
3. 先用沙盒账号 zth851 测试发布（沙盒只能发仅自己可见 SELF_ONLY）。测试通过后，等 yqh 生产应用审核通过，再换生产应用的凭证连接 6 个墨西哥店号（一次只连一个账号）。

Access Token 的获取方式（和之前 Muse 工具的连接方式一样）：在 TikTok 开发者后台用沙盒应用授权（Login Kit + video.publish + video.upload 三个 scope），拿到 code 后换 Token，再把 Access Token 和 Refresh Token 粘贴到这里。团队站点本身不走 OAuth 跳转，所以不需要在 TikTok 后台加新的回调地址。

## ⚠️ 登录方式待定（部署前必须先定）

当前实现是**单密码门禁占位方案**：全团队共用一个登录密码（deploy.sh 生成，存在服务器 `.env` 里）。**这不是最终决定。**

- 如果团队定**共用密码**：直接用 deploy.sh 生成的密码分给 4 个人，定期换密码。
- 如果团队定**每人一个账号**：需要在 server.js 里加 users 表和账号管理（注册/改密/停用），再部署。

**定下之前，不要把站点地址发给团队以外的人。**

## 文件说明

- `server.js` —— 全部后端逻辑（API、TikTok 客户端、队列、登录门禁）
- `public/` —— 前端页面（index.html 工具界面、login.html 登录页、app.js、style.css、home.html/terms.html/privacy.html 为 yqh 官网与法务页）
- `deploy.sh` —— 服务器一键部署脚本
- `yqh-publish-tool.service` —— systemd 服务
- `.env.example` —— 环境变量模板（不要把真实 `.env` 发给别人）
- `data/` —— 运行时数据（SQLite + 上传视频），部署时自动创建，不随代码包走

## 已知限制

- 队列数据只存在这台服务器上（Muse 工具里的旧队列不迁移，之前已发布的视频不受影响）。
- 上传上限 32MB（与 Muse 工具一致）。
- 一次只连一个 TikTok 账号；多账号支持等生产应用审核通过后再加。
